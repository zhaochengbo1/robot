echo  'KERNEL=="ttyUSB*", ATTRS{idVendor}=="10c4", ATTRS{idProduct}=="ea60",ATTRS{serial}=="0002", MODE:="0777", GROUP:="dialout",  SYMLINK+="huanyu_base"' >/etc/udev/rules.d/huanyu_base.rules
echo  'KERNEL=="ttyUSB*", ATTRS{idVendor}=="10c4", ATTRS{idProduct}=="ea60",ATTRS{serial}=="0003", MODE:="0777", GROUP:="dialout",  SYMLINK+="huanyu_laser"' >/etc/udev/rules.d/huanyu_laser.rules
echo  'SUBSYSTEMS=="usb", ATTRS{idVendor}=="2bc5", ATTRS{idProduct}=="0502", GROUP="users", MODE="0666"' >/etc/udev/rules.d/huanyu_depth.rules
echo  'SUBSYSTEMS=="usb", ATTRS{idVendor}=="1d6b", ATTRS{idProduct}=="0403", GROUP="users", MODE="0666"' >/etc/udev/rules.d/huanyu_astrargb.rules
echo  'SUBSYSTEMS=="usb", ATTRS{idVendor}=="1b3f", ATTRS{idProduct}=="8301", GROUP="users", MODE="0666"' >/etc/udev/rules.d/huanyu_camera.rules

service udev reload
sleep 2
service udev restart


